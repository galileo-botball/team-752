#include <kipr/wombat.h>

void Route()
{
    create3_drive_straight(0.65,0.5); // (distance, speed); Leave start box
    create3_drive_arc_degrees(.25, 85, .25); //radius, angle, speed; turn to collect rocks
    create3_drive_straight(-0.2, 0.5); //back-up after picking up rocks
    
    create3_rotate_degrees(-92, 150); //rotate 90 degrees for rock by lava tubes
    return;
    create3_drive_straight(0.6, 0.5); //back-up pick up rock by lava tube
    create3_drive_straight(-0.05, 0.5); //back-up after picking up rock by lava tube
    
    create3_rotate_degrees(70, 0.75); //rotate 90 degrees from last rock
    create3_drive_straight(0.5, 0.35); //move forwards
}

//void follow_line()
//{
void create_3_Pose()  
{
    Create3Pose pose;
    pose.position.x = 100.0;
	pose.position.y = 100.0;
	pose.position.z = 0.0;
    
    create3_navigate_to_pose(pose,10, 6, 1);
}

int main()
{
    printf("Hello Roomba\n");
    int status = create3_connect();
    printf("Status: %d\n", status);
    
    Route();
    //follow_line();
    //create_3_Pose();
    
    create3_wait();
  
    return 0;
}

